from django.contrib import admin
from showtable.models import Movies

# Register your models here.

admin.site.register(Movies)