from django.urls import path
from showtable import views

urlpatterns = [
    path('list', views.ListFunc),
    path('list/<str:name>',views.ListFuncOk,name='list'),
    path('insert', views.InsertFunc),
    path('insertok', views.InsertFuncOk),
    path('update', views.UpdateFunc),
    path('updateok', views.UpdateFuncOk),
    path('delete', views.DeleteFunc),
    
]
