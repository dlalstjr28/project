from django.shortcuts import render
from showtable.models import Movies
from mysql.connector import connection
from django.http.response import HttpResponseRedirect

# Create your views here.
def Main(request):
    return render(request, 'main.html')

def ListFunc(request):
    datas = Movies.objects.all()
    return render(request, 'list.html', {'movies':datas})
    ''' (데이터 받을 때 튜플로 받아야 됨)
    sql = "select * from my_sangpum_sangtab"
    cursor = connection.cursor()
    cursor.execute(sql)
    datas = cursor.fetchall()
    return render(request, 'list.html', {'sangpums':datas})
    '''

def ListFuncOk(request,name):
    datas = Movies.objects.filter(movie__icontains=name)
    return render(request, 'list.html', {'movies':datas})
    ''' (데이터 받을 때 튜플로 받아야 됨)
    sql = "select * from my_sangpum_sangtab"
    cursor = connection.cursor()
    cursor.execute(sql)
    datas = cursor.fetchall()
    return render(request, 'list.html', {'sangpums':datas})
    '''

def InsertFunc(request):
    return render(request, 'insert.html')

def InsertFuncOk(request):
    if request.method == 'POST':
        Movies(
            movie = request.POST.get('movie'),
            year = request.POST.get('year'),
        ).save()
    return HttpResponseRedirect('/showtable/list') #추가 후 목록보기

def UpdateFunc(request):
    #print(request.GET.get('id'))
    data = Movies.objects.get(id=request.GET.get('id'))
    #print(data)
    return render(request, 'update.html', {'show_one': data})

def UpdateFuncOk(request):
    if request.method == 'POST':
        upRec = Movies.objects.get(id=request.POST.get('id'))
        upRec.movie = request.POST.get('movie')
        upRec.year = request.POST.get('year')
        upRec.save()
    return HttpResponseRedirect('/showtable/list') #추가 후 목록보기

def DeleteFunc(request):
    delRec = Movies.objects.get(id=request.GET.get('id'))
    delRec.delete()
    return HttpResponseRedirect('/showtable/list') #추가 후 목록보기
