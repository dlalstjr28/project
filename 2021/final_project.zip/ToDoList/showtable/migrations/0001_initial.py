from django.db import migrations,models
from django.conf import settings
class Migration(migrations.Migration):
    
    initial = True

    dependencies = [
    ]
    operations = [
        migrations.CreateModel(
            name='Movies',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('movie', models.CharField(unique=True, max_length=100, blank=True, null=True)),
                ('movie_eng', models.CharField(max_length=100, blank=True, null=True)),
                ('year', models.IntegerField(blank=True, null=True)),
                ('country', models.CharField(max_length=20, blank=True, null=True)),
                ('genre',models.CharField(max_length=30, blank=True, null=True)),
                ('launching', models.CharField(max_length=30, blank=True, null=True)),
                ('director', models.CharField(max_length=20, blank=True, null=True)),
                ('img', models.CharField(max_length=300, blank=True, null=True)),
                ('story', models.CharField(max_length=500, blank=True, null=True)),
            ],
        ),
    ]
 