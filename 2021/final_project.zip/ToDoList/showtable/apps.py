from django.apps import AppConfig


class ShowtableConfig(AppConfig):
    name = 'showtable'
