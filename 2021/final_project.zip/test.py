from selenium import webdriver
from urllib.request import urlopen
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys
import time
import pymysql
 
chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument('--headless')
chrome_options.add_argument('--no-sandbox')
chrome_options.add_argument('--disable-dev-shm-usage')
 
path = '/python/pyhome/chromedriver'
 
result = []
link = "https://www.kobis.or.kr/kobis/business/mast/mvie/searchMovieList.do#none"
driver = webdriver.Chrome(executable_path=path,options=chrome_options)
driver.implicitly_wait(10)
driver.get(link)
check_num = 0
count = 5 ## 얼마나 수집할건지 count 가 나타내는 것은 목록입니다. 즉 count 가 40이면 40x10 = 400개가 수집되는 것입니다.
for _ in range(count):
        number = driver.find_elements_by_css_selector("#content > div.rst_sch > table > tbody > tr")
        button = driver.find_elements_by_css_selector("#pagingForm > div > ul > li")
        for j in range(1,len(number)+1):
            movies = driver.find_element_by_css_selector("#content > div.rst_sch > table > tbody > tr:nth-child("+str(j)+") > td:nth-child(1) > span > a").text
            movies_eng = driver.find_element_by_css_selector("#content > div.rst_sch > table > tbody > tr:nth-child("+str(j)+") > td:nth-child(2) > span > a").text
            year = driver.find_element_by_css_selector("#content > div.rst_sch > table > tbody > tr:nth-child("+str(j)+") > td:nth-child(4) > span").text
            country = driver.find_element_by_css_selector("#content > div.rst_sch > table > tbody > tr:nth-child("+str(j)+") > td:nth-child(5) > span").text
            genre = driver.find_element_by_css_selector("#content > div.rst_sch > table > tbody > tr:nth-child("+str(j)+") > td:nth-child(7) > span").text
            launching = driver.find_element_by_css_selector("#content > div.rst_sch > table > tbody > tr:nth-child("+str(j)+") > td:nth-child(8) > span").text
            director = driver.find_element_by_css_selector("#content > div.rst_sch > table > tbody > tr:nth-child("+str(j)+") > td:nth-child(9) > span").text
            try:
                    time.sleep(1)
                    driver.find_element_by_css_selector("#content > div.rst_sch > table > tbody > tr:nth-child("+str(j)+") > td:nth-child(1) > span > a").send_keys(Keys.ENTER) ## 사진 캡쳐하기 위함
                    img = driver.find_element_by_css_selector("div > div.item_tab.basic > div.ovf.info.info1 > a > img").get_attribute('src')
                    story = driver.find_element_by_css_selector("div > div.item_tab.basic > div > p").text.replace("\n","")
                    time.sleep(1)
                    close_button = driver.find_element_by_css_selector("body > div.ui-dialog.ui-corner-all.ui-widget.ui-widget-content.ui-front.ui-draggable.ui-resizable > div.ui-dialog-titlebar.ui-corner-all.ui-widget-header.ui-helper-clearfix.ui-draggable-handle > div.hd_layer > a:nth-child(3)")
                    close_button.click()
            except Exception as e :
                    close_button = driver.find_element_by_css_selector("body > div.ui-dialog.ui-corner-all.ui-widget.ui-widget-content.ui-front.ui-draggable.ui-resizable > div.ui-dialog-titlebar.ui-corner-all.ui-widget-header.ui-helper-clearfix.ui-draggable-handle > div.hd_layer > a:nth-child(3)")
                    close_button.click()
                    continue
            result.append((movies,movies_eng,year,country,genre,launching,director,img,story))
        time.sleep(5)
        if check_num == 9 :
            driver.find_element_by_css_selector("#pagingForm > div > a.btn.next").click()
            check_num = 1
        else :
            check_num+=1
            button[check_num].click()
        time.sleep(5)
driver.quit()
 
try: 
    with pymysql.connect(
        host="db",
        user="student",
        password="abc123", 
        charset="euckr"
    ) as connection:
        with connection.cursor() as cursor:
            create_db_query = "CREATE DATABASE if not exists test"
            cursor.execute(create_db_query)
 
except ConnectionError as e:
        print(e)
 
try :
        with pymysql.connect( 
            host="db",
            user="student",
            password="abc123", 
            database="test", 
            charset="euckr"
        ) as connection:
            with connection.cursor() as cursor:
                create_movie_table = """
                    create table if not exists movies (
                        id int auto_increment primary key,
                        movie varchar(100) unique key,
                        movie_eng varchar(100) ,
                        year int(10) ,
                        country varchar(20) ,
                        genre varchar(30) ,
                        launching varchar(30) ,
                        director varchar(20) ,
                        img varchar(300) ,
                        story varchar(500)
                    );
                """
                insert_movie_table = """
                    insert ignore into movies (movie,movie_eng,year,country,genre,launching,director,img,story) 
                    values (%s,%s,%s,%s,%s,%s,%s,%s,%s)
                """ 
                select_movie_table = 'select * from movies'
                cursor.execute(create_movie_table)
                cursor.execute("ALTER TABLE movies CONVERT TO character SET euckr;")
                cursor.executemany(insert_movie_table,result)
                cursor.execute(select_movie_table)
                check = cursor.fetchall()
                for line in check:
                    print(str(line[0])+"\t"+str(line[1])+"\t"+str(line[2])+"\t"+str(line[3]))
 
                connection.commit()
except ConnectionError as e:
            print(e)
