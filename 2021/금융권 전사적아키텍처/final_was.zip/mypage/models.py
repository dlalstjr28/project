from django.db import models
# Create your models here.

class Mypage(models.Model):
      trade_time = models.DateTimeField(auto_now_add=True)
      user = models.CharField(max_length=20 ,null=True)
      user_ip = models.CharField(max_length=40 , null=True)
