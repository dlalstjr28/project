from django.urls import path

from .views import *

urlpatterns = [
   path('',mypage, name='mypage'),
   path('trade/',trade , name='trade'),
   path('account/',account, name='account')
]
