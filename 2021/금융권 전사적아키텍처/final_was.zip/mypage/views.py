from django.shortcuts import render,redirect
from django.contrib import auth
from django.contrib.auth.models import User

from requests.api import head
# Create your views here.
import string
import random

from .models import *

access_token =""
refresh_token = ""
user_seq_no =""

import requests

def mypage(request):
    if request.method =="POST" :
        url = "https://testapi.openbanking.or.kr/oauth/2.0/token"
        data = {'client_id': 'c5849ac7-1a20-4494-8dea-713890835930' ,'client_secret': 'f0e2a1af-b9cc-41be-81a9-6d54651f3a7b' ,'redirect_uri':'http://localhost:8000/mypage','grant_type':'authorization_code'}
        headers = {'Content-type': 'application/x-www-form-urlencoded; charset=UTF-8'}
        code = request.POST['code']
        data['code'] = code
        result = requests.post(url,data=data,headers=headers)
        if result.status_code==200 :
            text = result.json()
            access_token = text['access_token']
            refresh_token = text['refresh_token']
            user_seq_no = text['user_seq_no']
            return render(request,'mypage.html',{'POST':text})
    else :
        return render(request,'mypage.html')

def trade(request):
    if request.method =="GET":
        url = "https://testapi.openbanking.or.kr/v2.0/account/transaction_list/fin_num"
        head = "Bearer "+"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiIxMTAwOTk2NjI1Iiwic2NvcGUiOlsiaW5xdWlyeSIsImxvZ2luIl0sImlzcyI6Imh0dHBzOi8vd3d3Lm9wZW5iYW5raW5nLm9yLmtyIiwiZXhwIjoxNjM1NjU5NjIwLCJqdGkiOiJjMGUwYzI1ZS02NTgzLTQ1NTktYWYyYS0zMmU5NTExNWIzZGUifQ.3Kb_AJaAaN3MNGlmLzfdVqkOMHonZLyy1Fc7xxsd8v0"
        get_header = {"Authorization":head} 
        result =""
        for i in range(len(string.digits)-1):
            result += random.choice(string.digits)
        result = "M202112822U" + result    
        params = {"bank_tran_id":result,"fintech_use_num":"120211282288932252332782","tran_dtime":"20210802160000","sort_order":"D","from_date":"20210701","to_date":"20210802","inquiry_base":"D","inquiry_type":"A"}   
        text = requests.get(url,headers=get_header,params=params)
        get_text = text.json()['res_list']
        return render(request,'trade.html',{'GET':get_text})
def account(request):

        get_url = "https://testapi.openbanking.or.kr/v2.0/user/me"
        get_text = "Bearer "+"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiIxMTAwOTk2NjI1Iiwic2NvcGUiOlsiaW5xdWlyeSIsImxvZ2luIl0sImlzcyI6Imh0dHBzOi8vd3d3Lm9wZW5iYW5raW5nLm9yLmtyIiwiZXhwIjoxNjM1NjU5NjIwLCJqdGkiOiJjMGUwYzI1ZS02NTgzLTQ1NTktYWYyYS0zMmU5NTExNWIzZGUifQ.3Kb_AJaAaN3MNGlmLzfdVqkOMHonZLyy1Fc7xxsd8v0"
        get_header = {"Authorization":get_text}
        get_data = {"user_seq_no":"1100996625"}
        get_info = requests.get(get_url,headers=get_header,params=get_data)
        get_text = get_info.json()['res_list']
        return render(request,'account.html',{'GET':get_text})
