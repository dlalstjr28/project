from django.contrib import auth
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.shortcuts import render, redirect

import pandas as pd
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
import json





# Create your views here.
def signup(request):
    if request.method == 'POST':
        if request.POST['password1'] == request.POST['password2']:
            if len(request.POST['password1']) < 8 :
                return render(request,'signup.html',{'error': 'password is too short!!'})
            user = User.objects.create_user(
                                            username=request.POST['username'],
                                            password=request.POST['password1'],
                                            email=request.POST['email'],)
            return redirect('home')
        return render(request, 'signup.html')
    return render(request, 'signup.html')

def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            auth.login(request, user)
            return redirect('board')
        else:
            return render(request, 'login.html', {'error': 'username or password is incorrect.'})
    else:
        return render(request, 'login.html')

def logout(request):
    auth.logout(request)
    return redirect('home')

def cached_model():
    model = SentenceTransformer('jhgan/ko-sroberta-multitask')
    return model

def get_dataset():
    df= pd.read_csv('/home/ubuntu/final_was/user/wellness_dataset.csv')
    df['embedding'] =df['embedding'].apply(json.loads)
    return df

# home

def home(request):
    if request.method =='POST':
        data = request.POST['input']
        model = SentenceTransformer('jhgan/ko-sroberta-multitask')
        df = get_dataset()
        embedding = model.encode(data)
        df['distance'] = df['embedding'].map(lambda x: cosine_similarity([embedding],[x]).squeeze())
        answer = df.loc[df['distance'].idxmax()]
        answer_chatbot = answer['챗봇']
        return render(request,'home.html',{'GET':answer_chatbot})
    return render(request, 'home.html')

